package ca.mcmaster.se2aa4.island.team212;

import static org.junit.jupiter.api.Assertions.*;

class ScanIslandTest {

}