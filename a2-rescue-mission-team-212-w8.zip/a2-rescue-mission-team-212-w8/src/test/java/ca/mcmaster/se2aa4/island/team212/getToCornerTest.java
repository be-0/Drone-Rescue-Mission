package ca.mcmaster.se2aa4.island.team212;

class getToCornerTest {

}