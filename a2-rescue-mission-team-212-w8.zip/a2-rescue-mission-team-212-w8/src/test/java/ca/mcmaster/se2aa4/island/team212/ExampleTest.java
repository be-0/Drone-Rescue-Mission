package ca.mcmaster.se2aa4.island.team212;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class ExampleTest {

    @Test
    public void sampleTest() {
        assertTrue(1 == 1);
    }


}
