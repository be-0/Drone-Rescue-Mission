package ca.mcmaster.se2aa4.island.team212;

import org.json.JSONObject;

public enum Action {
    changeHeadingRight,
    changeHeadingLeft,
    echoForwards,
    echoLeft,
    echoRight,
    flyForwards,
    scan,
    stop;
}

